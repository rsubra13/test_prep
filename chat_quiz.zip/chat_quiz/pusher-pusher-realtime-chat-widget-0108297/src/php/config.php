<?php
error_reporting(E_ALL);

define('APP_KEY', '8ee84a625443f33fef39');
define('APP_SECRET', '8a8cfd6f4518a44da7c2');
define('APP_ID', '59973');
?>